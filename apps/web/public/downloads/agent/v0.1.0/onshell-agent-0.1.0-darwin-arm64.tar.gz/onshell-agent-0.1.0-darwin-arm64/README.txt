Onshell Agent (darwin-arm64)

This program lets a browser on onshell.cloud open a terminal on THIS computer.
It runs as you, not as an administrator, and only while it is running.

  Pair it:   node onshell-agent.cjs pair <code>
  Start it:  node onshell-agent.cjs run
  Stop it:   Ctrl+C

  See what it has done:      node onshell-agent.cjs log
  Change who may connect:    node onshell-agent.cjs approval <trusted|ask|always>
  Run it at login:           node onshell-agent.cjs service

By default, only the account that paired this computer can connect without
someone here agreeing to it first.
